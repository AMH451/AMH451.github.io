var mainCharacter;
var gravity = 9.8/30.0;
var backgroundImage;
var mainCharacterImage;
var gameoverImage;
var monsterImage
var groundOffset = 100
var monsterArray = []
var narutoHB;
var starImage;
var stars = [];
var star;
var score = 0

function preload() {
  soundFormats('mp3', 'ogg');
  mySound = loadSound('GameOver.ogg');
}


function setup() {
  createCanvas(800, 400);
  
  mainCharacter = new Character(200, 200, 90)
  narutoHB = new HealthBar(10,10)
  backgroundImage = loadImage("./forest.gif")
  mainCharacterImage = loadImage("./naruto2.gif")
  monsterImage = loadImage("./deidara2.gif")
  gameoverImage = loadImage("./game over.png")
  starImage = loadImage("./ninjastar.png")
  
  var newMonster = new Character(600, 100, 120)
  newMonster.isMonster = true
  monsterArray.push(newMonster)
  
 mySound.setVolume(0.1);
  
}




function draw() {
  background(0, 200, 150);
  image(backgroundImage, 0, 0, width, height)
  
  if(keyIsDown(LEFT_ARROW)){
    //move left
    mainCharacter.xSpeed -= 1.0
  }
  
    if(keyIsDown(RIGHT_ARROW)){
    //move right
    mainCharacter.xSpeed += 1.0
  }
  
  mainCharacter.update();
  mainCharacter.draw();
  
  
  fill("white")
  textSize(20)
  text(score, width-40, 10, 40, 20)
  narutoHB.display()
  
  var anyCatAlive = false
  
  
  for(i=0;i<monsterArray.length;i++){
    if(monsterArray[i].isDead){
      //do nothing (bc monster is dead)
    }
    else{
    anyCatAlive = true
    monsterArray[i].update()
    monsterArray[i].draw()
    monsterArray[i].moveBadGuy()
    monsterArray[i].BadGuyisHit()
    }
}

  if(anyCatAlive == false){
    for(var i=0;i<3;i++ ){
      var newMonster = new Character(600+i*50, 100, 120)
      newMonster.isMonster = true
      monsterArray.push(newMonster)
    }
     
     }
  
  //displaying star
  for(var i=0;i<stars.length;i++){  
    stars[i].display()
    stars[i].move()
    
    //This code removes the star from the array if it's outside of the bounds of the screen:
    if(stars[i].x >= width)
    {
      //remove the star from our star array
      stars.splice(i, 1)
      i--
    }
  }
  
}

function keyPressed(){
  if(key === " " && mainCharacter.y > 250 ){
    //JUMP!
    mainCharacter.ySpeed -= 10.0
  }
  else if(keyCode == SHIFT)
  {
    star = new Star()
    stars.push(star)
  }
}


// function restart(){
//   if(narutoHB.health <= 0 && mouseIsPressed){
//     //restart sketch:
//     //https://www.youtube.com/watch?v=lm8Y8TD4CTM [4:07]
//   }
// }

