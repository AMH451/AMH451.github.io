class HealthBar{
 constructor(x , y){
   this.x = x
   this.y = y
   this.health = 100
 }
  
  display(){
 if(this.health > 0){
    fill("red")
    stroke("black")
    rect(this.x , this.y, this.health*2, 20)
 }
  else{
    image(gameoverImage, 300, 10, height/2, width/2)
    noLoop()
    

  mySound.play();

    
     }
  
  }

}