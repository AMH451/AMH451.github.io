class Star {
  constructor(){
   this.x = mainCharacter.x
   this.y = mainCharacter.y
   this.width = 40
   this.xSpeed = 0;
  }
  
  display(){
    image(starImage, this.x, this.y, this.width, this.width)
  }
  
  move(){
    //console.log("move")
     this.xSpeed += 0.5
     this.x += this.xSpeed 
  }
  
}