class Character {
  constructor(x, y, width) {
    this.x = x;
    this.y = y;
    this.ySpeed = 0;
    this.xSpeed = 0;
    this.width = width;
    this.color = "blue"
    this.isMonster = false
    this.isDead = false
    this.targetX = random() * width
  }

  update() {
    if (this.y + this.width * 0.5 >= (height - groundOffset) && this.ySpeed > 0) {
      this.ySpeed = this.ySpeed * (-0.4)
      this.y = height - this.width * 0.5 - groundOffset
    }
    this.ySpeed += gravity;
    this.y += this.ySpeed;

    if (this.isMonster == false) {
      this.xSpeed *= 0.8
    }
    this.x += this.xSpeed;
  }

  moveBadGuy() {
    var differenceX = this.targetX - this.x
    this.xSpeed += differenceX * 0.00001

    if (random() >= 0.98) {
      this.targetX = random() * width
      this.ySpeed -= 5
    }


    this.isTouchingMainCharacter()
  }

  isTouchingMainCharacter() {
    if (mainCharacter.x + mainCharacter.width >= this.x + 100 &&
      mainCharacter.x <= this.x + this.width &&
      mainCharacter.y + mainCharacter.width >= this.y &&
      mainCharacter.y <= this.y + this.width
    ) {
      stroke("black")
      noFill()
      rect(this.x, this.y, this.width, this.width)

      if (mainCharacter.y - this.y < -85) { //-30
        this.isDead = true
        mainCharacter.ySpeed = -10
        score++
      } else {
        narutoHB.health -= 0.2
      }
    }
  }

  draw() {

    if (this.isMonster) {
      image(monsterImage, this.x, this.y, this.width, this.width)
    } else {
      image(mainCharacterImage, this.x, this.y, this.width, this.width)
    }
  }

  BadGuyisHit() {
    for (var i = 0; i < stars.length; i++) {
        if (stars[i].x + stars[i].width >= this.x + 100 &&
            stars[i].x <= this.x + this.width &&
            stars[i].y + stars[i].width >= this.y &&
            stars[i].y <= this.y + this.width
           ) {
          //console.log("hit")
          this.isDead = true
          score++
          if(score == 30){
            console.log("you won!")
            //noloop() //why does it not work here?
          }
        
      }
    }
  }

}